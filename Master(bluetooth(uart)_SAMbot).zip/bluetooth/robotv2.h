/*
*  Biblioth�que de fonctions utilisables pour piloter le robot version 2         *
*                             carte SamBOARD rouge                                          *
*/


/*.............................................................................*/
/* Fonction  permettant d'initialiser le timer avec deux sortie PWM            */
/* sur les voies P2.2 et P2.4                                                  */
/* Cette fonction initialise aussi les lignes P2.1 et P2.5 qui d�terminent le  */
/* sens de rotation des moteurs                                                */
/*.............................................................................*/ 
void Init_Robot();



/*............................................................................*/
/* Fonction  permettant de choisir le sens de fonctionnement des moteurs      */
/*  Il y a quatre possibilit�s permettant d'avancer, reculer, tourner �       */
/*  gauche ou � droite.                                                       */
/*............................................................................*/

void Choix_direction(unsigned char sens);


/*............................................................................*/
/* Fonction  permettant de d�finir la vitesse des moteurs                     */
/*  Pour compenser les disparit�s des moteurs il faut envoyer deux vitesses   */
/*  gauche et droite. Les valeurs doivent �tre comprises entre 0 et 200       */
/*............................................................................*/

void Vitesse_moteurs(unsigned int vit_gauche, unsigned int vit_droite);


/*............................................................................*/
/* Fonction  permettant de stopper le robot par arr�t des commandes moteurs   */
/*............................................................................*/

void Arret_robot();



/*............................................................................*/
/* Fonction  permettant de d�marrer le robot par envoi des commandes moteurs  */
/*............................................................................*/

void Demarrer_robot();


/*............................................................................*/
/* Fonction r�alisant une temporisation param�tr�e en millisecondes max:65535 */
/*............................................................................*/

void tempo( unsigned int ms);
