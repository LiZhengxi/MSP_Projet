/*
 * TP1.c
 * XIE & LUO
 */
#include <msp430g2553.h>
#include "robotv2.h"
const unsigned char menu[] =
		"\n- 'z' pour avancer \r\n"
		"- 's' pour reculer\r\n"
		"- 'q' pour tourner a gauche\r\n"
        "-'d' pour tourner a droit\r\n"
        "-'n' pour arrêter le robot"
		"Entrez votre choix\r\n";

const unsigned char erreur[] = "\r\nIl y a une erreur!!\r\n";
/*
 * initialiser UART
 */
void InitUART(void) {

	P1SEL |= (BIT1 + BIT2);                 // P1.1 = RXD, P1.2=TXD
	P1SEL2 |= (BIT1 + BIT2);                // P1.1 = RXD, P1.2=TXD
	UCA0CTL1 |= UCSSEL_2;                   // SMCLK
	UCA0BR0 = 104;                          // 1MHz, 9600
	UCA0BR1 = 0;                            // 1MHz, 9600
	UCA0CTL0 &= ~UCPEN & ~UCPAR & ~UCMSB;
	UCA0CTL0 &= ~UC7BIT & ~UCSPB & ~UCMODE1;
	UCA0CTL0 &= ~UCMODE0 & ~UCSYNC;
	UCA0CTL1 &= ~UCSWRST;                   // **Initialize USCI state machine**


	IE2 |= UCA0RXIE;                        // Enable USCI_A0 RX interrupt
}
/*
 * initialiser ports
 */
void InitPort(void) {
	P1SEL &= (~BIT0 | ~BIT6);                 // P1.0 P1.6 output
	P1SEL2 &= (~BIT0 | ~BIT6);
	P1DIR |= BIT0;
}
/*
 * envoyer une caractere
 */
void TXdata(unsigned char c) {
	while (!(IFG2 & UCA0TXIFG));  // USCI_A0 TX buffer ready?
	UCA0TXBUF = c;              // TX -> RXed character
}

/*
 * envoyer la chaine des carateres
 */
void print_str(unsigned char *c)
{
	while (*c) {
		TXdata(*c++);
	}
}

void main(void) {
	WDTCTL = WDTPW + WDTHOLD;
	DCOCTL= 0;// Stop WDT
	BCSCTL1 = CALBC1_1MHZ;      // Set DCO to 1Mhz
	DCOCTL = CALDCO_1MHZ;       // Set DCO to 1Mhz

	P1OUT |= BIT0;

	InitUART();
	InitPort();
	Init_Robot();
    Vitesse_moteurs(200, 200);
	__bis_SR_register(GIE); // interrupts enabled

	print_str(menu);
	while (1);
}

// Echo back RXed character, confirm TX buffer is ready first
#pragma vector=USCIAB0RX_VECTOR
__interrupt void USCI0RX_ISR(void) {
	unsigned char c;

	c = UCA0RXBUF;
	TXdata(c);
	if (c == 'z') {
	    P1OUT ^= BIT0;
	    Choix_direction(2);  // 2 avancer, 0 tourner 锟� droit ,1 reculer , 3 tourner 锟� gauche
	    Demarrer_robot();

	} else if (c == 's') {
		P1OUT ^= BIT0;
		Choix_direction(1);  // 2 avancer, 0 tourner 锟� droit ,1 reculer , 3 tourner 锟� gauche
		Demarrer_robot();

	} else if (c == 'q') {
	    Choix_direction(3);  // 2 avancer, 0 tourner 锟� droit ,1 reculer , 3 tourner 锟� gauche
	    Demarrer_robot();
	    tempo(400);
	    Arret_robot();
	    Choix_direction(2);  // 2 avancer, 0 tourner 锟� droit ,1 reculer , 3 tourner 锟� gauche
	    Demarrer_robot();
	}
	else if (c == 'd') {
	        Choix_direction(0);  // 2 avancer, 0 tourner 锟� droit ,1 reculer , 3 tourner 锟� gauche
	        Demarrer_robot();
	        tempo(400);
	        Arret_robot();
	        Choix_direction(2);  // 2 avancer, 0 tourner 锟� droit ,1 reculer , 3 tourner 锟� gauche
	        Demarrer_robot();
	    }
	else if (c == 'n') {

	    Arret_robot();

	    }
	else{
		print_str(erreur);
	}
}
