/*
 * SPI_Init.h est la bibliotheque de SPI partie master
 */

#ifndef SPI_INIT_H_
#define SPI_INIT_H_

void SPI_Init();



#endif /* SPI_INIT_H_ */
