/*
 * SPI_Init.h
 *
 *  Created on: 2018��3��12��
 *      Author: Martin 1
 */

#ifndef SPI_INIT_H_
#define SPI_INIT_H_

void SPI_Init();



#endif /* SPI_INIT_H_ */
