/*
 * ADC.h
 *
 *  Created on: 2018��3��12��
 *      Author: Martin 1
 */

#ifndef ADC_H_
#define ADC_H_

void ADC_init(void);
void ADC_Demarrer_conversion(unsigned char voie);
int ADC_Lire_resultat ();
void initline();
#endif /* ADC_H_ */
