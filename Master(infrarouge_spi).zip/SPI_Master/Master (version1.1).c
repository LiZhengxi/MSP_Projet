/*
 * Version 1.2
 * Autheur : LiZhengxi && Jiang Zhuohang
 * Description : Le master permet de capturer le changement d'infrarouge
 * si la valeur reçue est supérieur à un certain chiffre. Il va envoyer 0x10 à slave
 * et slave va tourner un certain angle
 */
//******************************************************************************
#include <msp430.h>
#include "ADC.h"
#include "SPI_Init.h"

/***********
 * main()
 */
int infrarouge;
int main(void)
{
    WDTCTL = WDTPW | WDTHOLD;   // Stop watchdog time
      initline();
      ADC_init();
      SPI_Init();

   while(1)
   {
       do
           {
           ADC_Demarrer_conversion(0x00);
           infrarouge=ADC_Lire_resultat ();

           }while(infrarouge<=500);

           while (!(IFG2&UCB0TXIFG));
                 UCB0TXBUF = 0x10;                     // Transmit first character
                 __delay_cycles(50000);
   }
}

