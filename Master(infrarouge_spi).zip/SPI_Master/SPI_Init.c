/*
 * SPI_Init.c
 *
 *  Created on: 2018��3��12��
 *      Author: Martin 1
 */

#include"SPI_Init.h"
#include "msp430g2553.h"
void SPI_Init()
{
    P1DIR |= BIT5;                     //
      P1SEL = BIT5 + BIT7;      //BIT5 horloge ,BIT7 TX
      P1SEL2 = BIT5 + BIT7;
      UCB0CTL0 |= UCCKPL + UCMSB + UCMST + UCSYNC;  // 3-pin, 8-bit SPI master
      UCB0CTL1 |= UCSSEL_2;                     // SMCLK
      UCB0BR0 |= 0x02;                          // /mini diviser par 2
      UCB0BR1 = 0;                              //
      UCB0CTL1 &= ~UCSWRST;                     // **Initialize USCI state machine**
      __delay_cycles(75);                       // Wait for slave to initialize

}
