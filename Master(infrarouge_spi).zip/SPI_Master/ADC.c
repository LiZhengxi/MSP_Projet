/*
 * ADC.c
 *
 *  Created on: 2018年3月12日
 *      Author: Martin 1
 */

#include "msp430g2553.h"
#include "ADC.h"
void ADC_init(void)
{
      ADC10CTL0 = ADC10CTL1 = 0;

// Choix de la r锟絝锟絩ence de tension Vcc GND
// R锟絝锟絩ence interne active et g锟絥锟絩ateur 锟� 2,5 Volts  ADC10 actif
// Les autres bits sont suppos锟絪 锟� 0

      ADC10CTL0 =  SREF_0 + ADC10SHT_0  + REF2_5V + REFON + ADC10ON;  ;

// Choix du diviseur par 1 pour l'horloge, d锟絤arrage conversion logiciel
// Horloge de conversion 1MHz, conversion monovoie-monocoup

      ADC10CTL1 =  ADC10DIV_0 + ADC10SSEL_2 +  SHS_0 + CONSEQ_0 ;

}

void ADC_Demarrer_conversion(unsigned char voie)
{
    ADC10CTL1 = (voie * 0x1000)+ ADC10DIV_0 + ADC10SSEL_2 +  SHS_0 + CONSEQ_0 ;
    ADC10CTL0 |= ENC + ADC10SC;     // Sampling and conversion start
 }


int ADC_Lire_resultat ()
{
    while (ADC10CTL1 & ADC10BUSY);  // Tant que ADC occup锟� on attend
    ADC10CTL0 &= ~ENC;      // Conversion finie alors Disable ADC conversion

        return ADC10MEM;            // Return Conversion value
}

void initline(){
    P1SEL &= ~(BIT0);
    P1SEL2 &= ~(BIT0);
    P1DIR &= ~(BIT0);// pin 1.0 input
    ADC10AE0 |= BIT0;

    P1SEL &= ~(BIT6);
       P1SEL2 &= ~(BIT6);
       P1DIR &= ~(BIT6);// pin 1.6 input
       ADC10AE0 |= BIT6;
}

