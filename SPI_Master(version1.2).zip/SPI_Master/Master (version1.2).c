/*
 * Version 1.2
 * Autheur : LiZhengxi && Jiang Zhuohang
 * Description : Le master permet de capturer le changement d'infrarouge
 * si la valeur reçue est supérieur à un certain chiffre. Il va envoyer 0x10 à slave
 * et slave va tourner un certain angle
 */
//******************************************************************************
#include <msp430.h>

void ADC_init(void);
void ADC_Demarrer_conversion(unsigned char voie);
int ADC_Lire_resultat ();
void initline();
void GPIO_Init();
void P1_IODect();
void P13_Onclick();
void SPI_Init();
/***********
 * main()
 */
int infrarouge;
int main(void)
{ unsigned char MST_Data;
  volatile unsigned int i;
  initline();
  ADC_init();
  SPI_Init();

   while(1)
   {
       do
           {
           ADC_Demarrer_conversion(0x00);
           infrarouge=ADC_Lire_resultat ();

           }while(infrarouge<=300);

           while (!(IFG2&UCB0TXIFG));
                 UCB0TXBUF = 0x10;                     // Transmit first character
                 __delay_cycles(50);
   }
}

void SPI_Init()
{
    P1DIR |= BIT5;                     //
      P1SEL = BIT5 + BIT7;      //BIT5 horloge ,BIT7 TX
      P1SEL2 = BIT5 + BIT7;
      UCB0CTL0 |= UCCKPL + UCMSB + UCMST + UCSYNC;  // 3-pin, 8-bit SPI master
      UCB0CTL1 |= UCSSEL_2;                     // SMCLK
      UCB0BR0 |= 0x02;                          // /mini diviser par 2
      UCB0BR1 = 0;                              //
      UCB0CTL1 &= ~UCSWRST;                     // **Initialize USCI state machine**
      __delay_cycles(75);                       // Wait for slave to initialize

}
void ADC_init(void)
{
      ADC10CTL0 = ADC10CTL1 = 0;

// Choix de la r锟絝锟絩ence de tension Vcc GND
// R锟絝锟絩ence interne active et g锟絥锟絩ateur 锟� 2,5 Volts  ADC10 actif
// Les autres bits sont suppos锟絪 锟� 0

      ADC10CTL0 =  SREF_0 + ADC10SHT_0  + REF2_5V + REFON + ADC10ON;  ;

// Choix du diviseur par 1 pour l'horloge, d锟絤arrage conversion logiciel
// Horloge de conversion 1MHz, conversion monovoie-monocoup

      ADC10CTL1 =  ADC10DIV_0 + ADC10SSEL_2 +  SHS_0 + CONSEQ_0 ;

}

void ADC_Demarrer_conversion(unsigned char voie)
{
    ADC10CTL1 = (voie * 0x1000)+ ADC10DIV_0 + ADC10SSEL_2 +  SHS_0 + CONSEQ_0 ;
    ADC10CTL0 |= ENC + ADC10SC;     // Sampling and conversion start
 }


int ADC_Lire_resultat ()
{
    while (ADC10CTL1 & ADC10BUSY);  // Tant que ADC occup锟� on attend
    ADC10CTL0 &= ~ENC;      // Conversion finie alors Disable ADC conversion

        return ADC10MEM;            // Return Conversion value
}

void initline(){
    P1SEL &= ~(BIT0);
    P1SEL2 &= ~(BIT0);
    P1DIR &= ~(BIT0);// pin 1.0 input
    ADC10AE0 |= BIT0;

    P1SEL &= ~(BIT6);
       P1SEL2 &= ~(BIT6);
       P1DIR &= ~(BIT6);// pin 1.6 input
       ADC10AE0 |= BIT6;
}
